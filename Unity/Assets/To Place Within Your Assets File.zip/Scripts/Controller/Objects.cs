using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Objects : MonoBehaviour
{
	#region "Variables"
	public GameObject Player;
	public GameObject MainCamera;
	public List<GameObject> ObjectOfInterestCollection = new List<GameObject>();
	#endregion
}
